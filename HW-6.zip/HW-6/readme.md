# Homework 5

I think this week's assignment went pretty well for me, even with a few issues. Hopefully the end result is correct due to my referencing Professor Cassens' example code. I started out trying to formulate arrays on my own, but I had some problems calling images into arrays. I would like to do more styling with this assignment when I have time. I look forward to next week's addition to the assignment.
